# philosophy

## Provenance (ruled 2026-10-11)

Every file is one of:

- **HAND** — written by the user, by hand.
- **AGENT-REVIEWED** — written by an agent; the user read it and approved it
  with informed consent, knowing what it does and what it assumes.
- **AGENT** — written by an agent and not yet reviewed line by line by the
  user. Decisions it embodies are the agent's, not the project's, until
  ruled.

Orthogonal to authorship:

- **TESTED** — Only TESTED code is tried. HAND code that never ran is a draft.

`PROVENANCE.md` is the ledger. A change set that touches a file updates its
row. An agent never confuses "HAND" with "tested" and never confuses
"ran once in a scenario" with "ruled correct".

# General:

## Intent before change

When a request leaves room for interpretation, ask for the exact intent.
Never resolve ambiguity by assumption. The same bar applies to adding
anything unasked: no features nobody has proven they need, no guards against
edge cases never seen or shown possible. When an assumption was unavoidable
to keep moving, it is written down as an OPEN RULING in RULINGS.md, with the
alternative readings, and the user rules on it. An unruled assumption is not
design.

## Determining intent
When performing low level tasks that involve design and user intent, like writing code or editing layouts,
give short updates, and ask questions when going from one task to the next, or from one
function or struct to the next, to prevent unnecessary work and avoid wasting time

**How to apply:** one or two lines of text between steps (what was done, what
is next). At a boundary where a real choice exists, stop and ask one focused
question before writing the next piece. Do not batch many functions into one
silent change.

## Code
Reference:
“The Exceptional Beauty of Doom 3's Source Code” — Shawn McGrath on id Software's C++ (http://web.archive.org/web/20130401084122/http://kotaku.com/5975610/the-exceptional-beauty-of-doom-3s-source-code).
"Clean" Code, Horrible Performance - Casey Muratori https://www.computerenhance.com/p/clean-code-horrible-performance
Data Oriented Design - https://en.wikipedia.org/wiki/Data-oriented_design
- **What code is**: 
All code is about accepting input data, mutating it and outputting other data.
To write performant, comprehensible and maintainable code, all possible inputs,
mutation paths and outputs need to be legible, finite and human-readable
- **Single source of truth**:
Every single system should have one place where a given data element is Mastered.
All other places don't write or edit that data element, and they explicitly
say their information is a flawed copy and specify when it was last reconciled
with the Master.
- **Hierarchy**
Strict hierarchy, the old HTML discipline: the ancestor determines
everything about its descendants. A descendant never decides something
about itself that its parent should own. Brutal, but a descendant deciding
silently in the wrong direction is how everyone dies. Corollary: empty files
are deleted on sight; if something breaks, that is the parent's fault for
relying on an empty file. Similarly, the ancestor determines all
interactions between its descendants. This means they don't have to
know anything about the rest of the world, they don't have to make calls
to other elements, they don't have to make calls to their Master, they 
just do what they were asked to do.
- **Separation of data and functions**
We don't do clown fiesta OOP like Animal:Dog>Bark(). A dog is a data struct
that stores information like bark_sfx and withers_height. It barks when 
its Master tells it to bark.
- **No null wearing a value's clothes.** Absent means absent: boundaries
check types explicitly (`Array.isArray(flags)`, not truthiness), and an
unset override falls through to the decider — it never masquerades as a
configuration.
- **Minimize state and make it easily mutable**:
NO setters, NO getters, NO override layers. There is ONE state object per
concern; "setting" it MUTATES that object, and after an override there is
only the overridden state — never a shadow copy in the caller, never a
base-plus-patches stack a reader has to collapse in their head.
- **Don't try to fix bugs as they appear,  make them IMPOSSIBLE BY DEFINITION**
Weird machines suggest that every single state machine is going to be able to
create malformed abominations inside of itself, which will also have undesirable states of their own,
aka bugs, and so an infinite number of bugs is going to exist in a badly written
codebase by default. Instead of trying to reduce infinity to smaller infinity,
make sure your code has a finite number of clear states it can take, and 
each of those states is intentional and well-defined
- **Code is self-documenting; comments are avoided whenever possible.**
A comment duplicates work at both write and read time; code that needs
one to be understandable should usually be rewritten instead.
(Reconciliation with this repo's comment-heavy style: the comments worth
keeping here are WHY-comments — decisions, repealed laws, paid-for quirks
— never WHAT-comments narrating the next line. When a WHAT-comment
appears necessary, that is the rewrite signal Doom 3 means.)
- **Locally coherent.** 
**Local code explains — or at least hints at — the overall system
design.** Reading any one place should teach you the shape of the whole.
This makes comments 
- **Legible control flow**
A tight loop in a highly performant application that runs every single frame
makes it obvious what data comes in, what happens to it and why, and what comes out.
Execution order is strict and deterministic, killing numerous classes of bugs before they spawn.
- **Reading code is MUCH harder than writing it**
Most of the work of a software engineer is READING and UNDERSTANDING code.
Make code EASY TO READ AND UNDERSTAND. Do NOT write 'clever' code.
You can confidently DELETE code, if it no longer runs and
has been made obsolete by something else. ADDING code is the thing that
potentially costs billions of manhours of extra work down the line,
multiplies bugs and unexpected behavior, and sometimes doesn't even provide any value.
So ADDING code is the decision you should be carefully debating, not REMOVING it.
LLMs spare humans thousands of hours of anguish and frustration by being able to
read giant bloated rotting codebases and turn them into streamlined and maintainable works of art.
- **Demolition**
When a replacement is finished and shown to work, the thing it replaced is
removed in the same change set — unless explicitly ruled otherwise. A
superseded mechanism left standing is not backup, it is a second writer
with a stale gate. Outdated code is deleted as soon as it is outdated.

- **Scenarios, not tests**
Tests are rapidly made outdated while developing new features,
can fail to catch unexpected behavior due to it being nominally correct,
are extremely slow and bloated and may influence codebases to change
themselves just to make sure a test written months ago passes. Instead, we should
use scenarios to develop mechanics/features in. A scenario may state a question and a
few expected results in plain words; running a script should say whether they
hold. Nothing stores a log of a run. Do not add checks that pin down how a
mechanic works today; add a scenario that shows what it is for.

- **WE ALWAYS VENDOR OUR DEPENDENCIES.** Every font, library, runtime and
trace lives in this repo as the bytes we ship — no package managers in the
serving path, no registry fetch between us and a working page. A project
reopened after weeks must run EXACTLY as it was left; "urgent client work"
must never begin with debugging someone else's resolver (the Ruby lesson:
a gem graph and a libpq build error own your morning, not you). The repo
already complies — fonts/, support.js (dc-runtime + React), suits/,
glyphs/ — keep it that way. A new dependency is admitted by copying its
built artifact in, pinned, with its origin and version noted beside it.

Reference: “Always vendor your dependencies” — Valigo (Valentin
Ignatiev), https://youtu.be/s7uji5kJakI. The law above IS its thesis. The
cautionary line behind it: ecosystems that made the resolver the centre of
the workflow (Rails and its gem graph, Homebrew) rotted from exactly
there — a project's ability to RUN must never be custodied by
infrastructure that can drift while you sleep. Corollary for us: the
serving path contains only files in this repo, and a dependency is a FILE
we adopted, not a name we request.
-- **Verification is spelled out**

Never a bare "verified". A report lists what ran and what it checked:
`✓ move: 3 steps at 360 ms · ✓ reach: impact tick 32 · ✓ twostrikes:
second waits on capacity`.

# Codebase-specific:

